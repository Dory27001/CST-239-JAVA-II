package app;

public class Main {
    public static void main(String[] args) {
        StoreFront store = new StoreFront();
        store.runStore(); // Start the store interaction
    }
}
